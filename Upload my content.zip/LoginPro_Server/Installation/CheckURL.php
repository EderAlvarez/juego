<?php

if(isset($_POST['Action'])) { $ACTION = $_POST['Action']; }
if($ACTION == "CheckURL") { echo "SUCCESS"; }

?>